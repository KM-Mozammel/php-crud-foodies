<?php
    @include 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>  
    <link rel="stylesheet" href="css/search.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"/>
    
</head>
<body>
    <?php include 'header.php';?>
    <div class="search_container">
        <center><h3>Search Result</h3></center>
        <table>
            <thead>
                <th>Image</th>
                <th>Name</th>
                <th>price</th>
            </thead>
            <tbody>
                <?php
                    if(isset($_POST['submit']) && !empty($_POST['keyword'])){
                        $keyword = $_POST['keyword'];
                        $search_query = mysqli_query($conn, "SELECT * FROM `products` WHERE name like '%".$keyword."%'");
                        if(mysqli_num_rows($search_query) > 0){
                            while($fetch = mysqli_fetch_assoc($search_query)){
                ?>
                <tr>
                    <td><img src="uploaded_img/<?php echo $fetch['image'];?>" width="100" alt=""></td>
                    <td>
                        <?php echo $fetch['name'];?>
                    </td>                        
                    <td><?php echo $fetch['price'];?></td>
                </tr>
                <?php
                            }
                        }
                    } else{
                        header("location: products.php");
                    }
                ?>
            </tbody>
        </table>
    </div>
    
<script src="js/script.js"></script>
</body>
</html>