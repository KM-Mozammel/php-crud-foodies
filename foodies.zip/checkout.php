<?php
    @include 'config.php';
    if(isset($_POST['order_btn'])){
        $name = $_POST['name'];
        $number = $_POST['number'];
        $email = $_POST['email'];
        $method = $_POST['method'];
        $flat = $_POST['flat'];
        $street = $_POST['street'];
        $city = $_POST['city'];
        $state = $_POST['state'];
        $country = $_POST['country'];
        $pin_code = $_POST['pin_code'];

        $cart_query = mysqli_query($conn, "SELECT * FROM `cart`");
        $price_total = 0;
        if(mysqli_num_rows($cart_query) > 0){
            while($product_item = mysqli_fetch_assoc($cart_query)){
                $product_name[] = $product_item['name'].' ('.$product_item['quantity'].')';
                $product_price = number_format($product_item['price'] * $product_item['quantity']);
                $price_total += $product_price;
            };
        };
        $total_product = implode(', ', $product_name);
        $detail_query = mysqli_query($conn, "INSERT INTO `order`(name, number, email, method, flat, street, city, state, country, pin_code, total_products, total_price) VALUES('$name', '$number', '$email', '$method', '$flat', '$street', '$city', '$state', '$country', '$pin_code', '$total_product', '$price_total')");

        if($cart_query && $detail_query){
            echo "
            <div class='order-message-container'>
            <div class='message-container'>
                <h3>thank you for shopping!</h3>
                <div class='order-detail>
                    <span class='total'>".$total_product."</span>
                    <span class='total'> total : ".$price_total."</span>
                </div>
                <div class='customer-details'>
                    <p>your name : <span>".$name."</span></p>
                    <p>your number : <span>".$number."</span></p>
                    <p>your email : <span>".$email."</span></p>
                    <p>your address : <span>".$flat.",".$street.",".$city.",".$state.",".$country."-".$pin_code."</span></p>
                    <p>your payemnt mode : <span></span></p>
                    <p>(*pay when product arrives*)</p>
                </div>
                <a href='products.php' class='btn'>continue shopping</a>
                </div>
            </div>
            ";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>    
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"/>
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="container">
        <section class="checkout-form">
            <h1 class="heading">complete your order</h1>
            <form action="" method="post">
            <div class="display-order">
                <?php
                    $select_cart = mysqli_query($conn, "SELECT * FROM `cart`");
                    $total = 0;
                    $grand_total = 0;
                    if(mysqli_num_rows($select_cart)){
                        while($fetch_cart = mysqli_fetch_assoc($select_cart)){
                        $total_price = number_format($fetch_cart['quantity'] * $fetch_cart['price']);
                        $grand_total = $total += $total_price;
                ?>   
                <span><?= $fetch_cart['name']; ?>(<?= $fetch_cart['quantity']; ?>)</span>
                <?php         
                        };
                    }else{
                        echo "<div class = 'display-order'><span>Your cart is empty!</span></div>";
                    }

                ?>
                <span  class="grand-total"> grand total : <?= $grand_total; ?></span>
            </div>
                <div class="flex">
                    <div class="inputBox">
                        <span>Your Name</span>
                        <input type="text" placeholder="enter your name" name="name">
                    </div>
                    <div class="inputBox">
                        <span>your number</span>
                        <input type="number" placeholder="enter your number" name="number" required>
                    </div>
                    <div class="inputBox">
                        <span>your email</span>
                        <input type="email" placeholder="enter your number" name="email" required>
                    </div>
                    <div class="inputBox">
                        <span>payment method</span>
                        <select name="method" id="">
                            <option value="cash on delivery">Cash on delivery</option>
                            <option value="Visa">visa card</option>
                            <option value="bkash" selected>bkash</option>
                        </select>
                    </div>
                    <div class="inputBox">
                        <span>Address line 1</span>
                        <input type="text" placeholder="e.g. flat no." name="flat" required>
                    </div>
                    <div class="inputBox">
                        <span>Address line 2</span>
                        <input type="text" placeholder="e.g. street name" name="street" required>
                    </div>
                    <div class="inputBox">
                        <span>city</span>
                        <input type="text" placeholder="e.g. dhaka" name="city" required>
                    </div>
                    <div class="inputBox">
                        <span>state</span>
                        <input type="text" placeholder="e.g. dhanmondi" name="state" required>
                    </div>
                    <div class="inputBox">
                        <span>country</span>
                        <input type="text" placeholder="e.g. Bangladesh" name="country" required>
                    </div>
                    <div class="inputBox">
                        <span>pin code</span>
                        <input type="text" placeholder="e.g. 1234567" name="pin_code" required>
                    </div>
                </div>
                <input type="submit" value="order now" name="order_btn" class="btn">
            </form>
        </section>
    </div>

<script src="js/script.js"></script>
</body>
</html>